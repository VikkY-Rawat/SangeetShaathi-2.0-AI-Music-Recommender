"""Normalize a downloaded/authorized song metadata CSV into data/songs.csv.

Usage:
  python prepare_dataset.py path/to/source.csv --source-name "Dataset title" --license "MIT"
The script does not scrape websites or fabricate missing records. It maps common column names,
deduplicates title+artist, and reports how many usable records remain.
"""
import argparse
from pathlib import Path
import re
import pandas as pd

ROOT=Path(__file__).resolve().parent
OUT=ROOT/"data"/"songs.csv"
ALIASES={
 "song_id":["song_id","id","song_uuid","uuid","track_id","music_id"],
 "title":["title","song_title","song_name","music_name","track_name","name"],
 "artist":["artist","artists","singer","singers","artist_name","vocalist"],
 "album":["album","album_name","album_title","movie","film"],
 "year":["year","release","release_year","album_year"],
 "language":["language","lang"],
 "genre":["genre","genres","music_genre"],
 "mood_tags":["mood_tags","mood","emotion","tags","labels"],
 "energy":["energy","danceability"],
 "valence":["valence","positivity"],
 "description":["description","summary","lyrics","overview"],
 "link":["link","url","youtube_url","spotify_url","track_url"],
 "artwork_url":["artwork_url","thumbnail","image","image_url","cover_url"]
}
def norm_name(s):
    return re.sub(r"[^a-z0-9]+","_",str(s).strip().lower()).strip("_")
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("input_csv")
    ap.add_argument("--source-name",default="User-supplied dataset")
    ap.add_argument("--license",default="Verify source license before redistribution")
    ap.add_argument("--append",action="store_true",help="Merge with current catalog before deduplication")
    args=ap.parse_args()
    source=Path(args.input_csv)
    if not source.exists(): raise SystemExit(f"Input not found: {source}")
    raw=pd.read_csv(source,low_memory=False).fillna("")
    original_cols={norm_name(c):c for c in raw.columns}
    out=pd.DataFrame()
    for target,choices in ALIASES.items():
        match=next((original_cols[c] for c in choices if c in original_cols),None)
        out[target]=raw[match] if match else ""
    out["title"]=out["title"].astype(str).str.strip()
    out["artist"]=out["artist"].astype(str).str.strip()
    out=out[(out.title!="") & (out.artist!="")].copy()
    out["year"]=pd.to_numeric(out["year"],errors="coerce")
    out["year"]=out["year"].apply(lambda x:int(x) if pd.notna(x) and 1800<=x<=2100 else "")
    out["language"]=out["language"].replace("","Hindi")
    out["genre"]=out["genre"].replace("","Bollywood / Unknown")
    out["mood_tags"]=out["mood_tags"].astype(str).str.replace(",", "|",regex=False).str.lower()
    out["source"]=args.source_name
    out["license"]=args.license
    out["energy"]=pd.to_numeric(out["energy"],errors="coerce")
    out["valence"]=pd.to_numeric(out["valence"],errors="coerce")
    # A conservative duplicate key preserves distinct versions if their artist/title differs.
    out["_key"]=(out.title.str.lower().str.replace(r"[^a-z0-9]+"," ",regex=True).str.strip()
                 +"::"+out.artist.str.lower().str.replace(r"[^a-z0-9]+"," ",regex=True).str.strip())
    out=out.drop_duplicates("_key").drop(columns="_key")
    if args.append and OUT.exists():
        current=pd.read_csv(OUT).fillna("")
        out=pd.concat([current,out],ignore_index=True,sort=False).fillna("")
        out["_key"]=(out.title.astype(str).str.lower().str.replace(r"[^a-z0-9]+"," ",regex=True).str.strip()
                     +"::"+out.artist.astype(str).str.lower().str.replace(r"[^a-z0-9]+"," ",regex=True).str.strip())
        out=out.drop_duplicates("_key",keep="first").drop(columns="_key")
    out=out.reset_index(drop=True)
    out["song_id"]=range(1,len(out)+1)
    columns=["song_id","title","artist","album","year","language","genre","mood_tags","energy","valence","description","source","license","link","artwork_url"]
    for c in columns:
        if c not in out: out[c]=""
    out[columns].to_csv(OUT,index=False)
    print(f"Input rows: {len(raw):,}")
    print(f"Valid unique title/artist pairs: {len(out):,}")
    print(f"Output: {OUT}")
    print("Note: this script does not infer reliable mood labels from missing metadata.")
    if len(out)<1000: print(f"WARNING: catalog is below the 1,000-song target by {1000-len(out):,} records.")
if __name__=="__main__": main()
