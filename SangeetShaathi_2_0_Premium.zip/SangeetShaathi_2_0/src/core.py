from pathlib import Path
import sqlite3
import numpy as np
import pandas as pd
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

ROOT = Path(__file__).resolve().parents[1]
EMOTION_DIR = ROOT / "models" / "emotion"
EMBED_DIR = ROOT / "models" / "embeddings"
SONGS_PATH = ROOT / "data" / "songs.csv"
DB_PATH = ROOT / "data" / "feedback.sqlite3"

EMOTION_TO_MOOD = {
    "joy": "joy", "love": "love", "sadness": "sadness",
    "anger": "anger", "fear": "fear", "frustration": "anger",
    "gratitude": "hope", "surprise": "joy", "neutral": "calm",
    "contempt": "anger", "disgust": "anger"
}
UPLIFT_WORDS = ("better", "uplift", "motivate", "motivation", "cheer me", "feel good",
                "positive", "energy", "happy", "inspire", "hopeful", "mood improve",
                "mood better", "better feel", "khush", "energetic", "motivate karo")
CALM_WORDS = ("calm", "peace", "relax", "soothe", "sleep", "shaant", "sukoon")
SAD_WORDS = ("sad song", "sad songs", "cry", "heartbreak", "dard bhare", "dukhi")

def init_db():
    with sqlite3.connect(DB_PATH) as con:
        con.execute("""CREATE TABLE IF NOT EXISTS feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            song_id INTEGER NOT NULL,
            action TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS favorites (
            song_id INTEGER PRIMARY KEY,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS recent_searches (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            query TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")

def get_feedback():
    init_db()
    with sqlite3.connect(DB_PATH) as con:
        return pd.read_sql_query("SELECT song_id, action FROM feedback", con)

def save_feedback(song_id, action):
    init_db()
    with sqlite3.connect(DB_PATH) as con:
        con.execute("INSERT INTO feedback(song_id, action) VALUES (?, ?)", (int(song_id), action))

class SangeetEngine:
    def __init__(self):
        if not EMOTION_DIR.exists() or not any(EMOTION_DIR.iterdir()):
            raise FileNotFoundError("Emotion model missing. Run: python download_models.py")
        if not EMBED_DIR.exists() or not any(EMBED_DIR.iterdir()):
            raise FileNotFoundError("Embedding model missing. Run: python download_models.py")
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.tokenizer = AutoTokenizer.from_pretrained(str(EMOTION_DIR), local_files_only=True)
        self.emotion_model = AutoModelForSequenceClassification.from_pretrained(
            str(EMOTION_DIR), local_files_only=True
        ).to(self.device)
        self.emotion_model.eval()
        self.embedder = SentenceTransformer(str(EMBED_DIR), device=self.device, local_files_only=True)
        self.songs = pd.read_csv(SONGS_PATH).fillna("")
        self.songs["song_id"] = self.songs["song_id"].astype(int)
        self.song_texts = (
            self.songs["title"].astype(str) + " by " + self.songs["artist"].astype(str)
            + ". Mood: " + self.songs["mood_tags"].astype(str).str.replace("|", ",", regex=False)
            + ". " + self.songs["description"].astype(str)
        ).tolist()
        self.song_embeddings = self.embedder.encode(
            self.song_texts, normalize_embeddings=True, convert_to_numpy=True,
            show_progress_bar=False
        )

    @torch.inference_mode()
    def detect_emotions(self, text):
        inputs = self.tokenizer(text, return_tensors="pt", truncation=True, max_length=192)
        inputs = {k: v.to(self.device) for k, v in inputs.items()}
        logits = self.emotion_model(**inputs).logits[0]
        # This model is multi-label: each emotion gets an independent sigmoid probability.
        probs = torch.sigmoid(logits).cpu().numpy()
        labels = self.emotion_model.config.id2label
        scores = {str(labels[int(i)]).lower(): float(probs[i]) for i in range(len(probs))}
        top = max(scores, key=scores.get) if scores else "neutral"
        return top, scores

    def infer_intent(self, text):
        t = text.lower()
        if any(w in t for w in UPLIFT_WORDS):
            return "uplifting"
        if any(w in t for w in CALM_WORDS):
            return "calm"
        if any(w in t for w in SAD_WORDS):
            return "match"
        return "match"

    def recommend(self, text, top_k=6, liked_ids=None, disliked_ids=None):
        emotion, emotion_scores = self.detect_emotions(text)
        intent = self.infer_intent(text)
        mood = EMOTION_TO_MOOD.get(emotion, emotion)
        query = self.embedder.encode([text], normalize_embeddings=True, convert_to_numpy=True)[0]
        semantic = cosine_similarity(query.reshape(1, -1), self.song_embeddings)[0]
        ranked = self.songs.copy()
        ranked["semantic_score"] = semantic
        tags = ranked["mood_tags"].str.lower()
        if intent == "uplifting":
            target_tags = ["uplifting", "hope", "motivation", "joy", "energy"]
        elif intent == "calm":
            target_tags = ["calm", "reflection", "spiritual"]
        else:
            target_tags = [mood, "love" if mood == "love" else mood]
        ranked["mood_score"] = tags.apply(
            lambda s: min(1.0, sum(1 for tag in target_tags if tag in s.split("|")) / max(1, min(2, len(target_tags))))
        )
        # Weighted ranking: semantic relevance is learned from neural embeddings;
        # metadata match and user feedback provide transparent personalization.
        ranked["final_score"] = 0.68 * ranked["semantic_score"] + 0.32 * ranked["mood_score"]
        liked_ids = set(liked_ids or [])
        disliked_ids = set(disliked_ids or [])
        ranked.loc[ranked["song_id"].isin(liked_ids), "final_score"] += 0.12
        ranked.loc[ranked["song_id"].isin(disliked_ids), "final_score"] -= 0.35
        ranked = ranked[~ranked["song_id"].isin(disliked_ids)]
        ranked = ranked.sort_values("final_score", ascending=False).head(int(top_k))
        return emotion, emotion_scores, intent, mood, ranked
