from pathlib import Path
import sqlite3
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
CSV_PATH=ROOT/"data"/"songs.csv"
DB_PATH=ROOT/"data"/"feedback.sqlite3"

def _connect():
    con=sqlite3.connect(DB_PATH)
    con.execute("""CREATE TABLE IF NOT EXISTS favorites (
        song_id INTEGER PRIMARY KEY,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")
    con.execute("""CREATE TABLE IF NOT EXISTS recent_searches (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        query TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")
    return con

def load_catalog():
    if not CSV_PATH.exists():
        return pd.DataFrame(columns=["song_id","title","artist","album","year","language","genre","mood_tags","energy","valence","description","source","license","link","artwork_url"])
    df=pd.read_csv(CSV_PATH).fillna("")
    required=["song_id","title","artist","album","year","language","genre","mood_tags","energy","valence","description","source","license","link","artwork_url"]
    for c in required:
        if c not in df.columns: df[c]=""
    df["title"]=df["title"].astype(str).str.strip()
    df["artist"]=df["artist"].astype(str).str.strip()
    df=df[(df.title!="") & (df.artist!="")].copy()
    df["song_id"]=pd.to_numeric(df["song_id"],errors="coerce")
    df=df.dropna(subset=["song_id"])
    df["song_id"]=df["song_id"].astype(int)
    df=df.drop_duplicates(subset=["song_id"],keep="first")
    df["year"]=pd.to_numeric(df["year"],errors="coerce")
    df["year"]=df["year"].apply(lambda x:int(x) if pd.notna(x) else "")
    return df.reset_index(drop=True)

def get_favorites():
    with _connect() as con:
        return [int(r[0]) for r in con.execute("SELECT song_id FROM favorites ORDER BY created_at DESC").fetchall()]

def toggle_favorite(song_id):
    with _connect() as con:
        exists=con.execute("SELECT 1 FROM favorites WHERE song_id=?",(int(song_id),)).fetchone()
        if exists: con.execute("DELETE FROM favorites WHERE song_id=?",(int(song_id),))
        else: con.execute("INSERT OR IGNORE INTO favorites(song_id) VALUES (?)",(int(song_id),))

def save_recent(query):
    with _connect() as con:
        con.execute("INSERT INTO recent_searches(query) VALUES (?)",(str(query)[:1000],))
